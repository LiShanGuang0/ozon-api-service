from fastapi import FastAPI

from app.api.router import api_router
from app.core.config import get_settings
from app.core.exceptions import register_exception_handlers
from app.core.logging import configure_logging
from app.core.responses import ApiResponseEnvelopeMiddleware


def create_app() -> FastAPI:
    configure_logging()
    settings = get_settings()
    application = FastAPI(title=settings.app_name)
    application.add_middleware(ApiResponseEnvelopeMiddleware)
    register_exception_handlers(application)
    application.include_router(api_router)
    return application


app = create_app()


@app.get("/health")
def health() -> dict[str, str]:
    settings = get_settings()
    return {"status": "ok", "service": settings.app_name}
