"""Pydantic schema modules."""
