from typing import Any

from app.clients.ozon_endpoints import OzonEndpoint
from app.core.exceptions import ServiceError
from app.core.security import OzonCredentials
from app.repositories.products import ProductRepository
from app.services.ozon_forwarder import OzonForwarder


class ProductQueryService:
    def __init__(
        self,
        forwarder: OzonForwarder | None = None,
        products: ProductRepository | None = None,
    ) -> None:
        self.forwarder = forwarder or OzonForwarder()
        self.products = products or ProductRepository()

    async def info_limit(self, *, credentials: OzonCredentials) -> dict[str, Any]:
        return await self.forwarder.post(OzonEndpoint.PRODUCT_INFO_LIMIT, {}, credentials)

    async def pictures_import(self, *, payload: dict[str, Any], credentials: OzonCredentials) -> dict[str, Any]:
        offer_id = payload.get("offer_id")
        if not offer_id:
            raise ServiceError("offer_id is required", status_code=422, detail={"field": "offer_id"})

        product_id = await self._resolve_product_id_by_offer_id(offer_id=str(offer_id), credentials=credentials)
        request_payload = {
            "product_id": product_id,
            "images": payload.get("images") or [],
            "images360": payload.get("images360") or [],
            "color_image": payload.get("color_image"),
        }
        return await self.forwarder.post(OzonEndpoint.PRODUCT_PICTURES_IMPORT, request_payload, credentials)

    async def info_list(self, *, payload: dict[str, Any], credentials: OzonCredentials) -> dict[str, Any]:
        return await self.forwarder.post(OzonEndpoint.PRODUCT_INFO_LIST, payload, credentials)

    async def info_attributes(self, *, payload: dict[str, Any], credentials: OzonCredentials) -> dict[str, Any]:
        return await self.forwarder.post(OzonEndpoint.PRODUCT_INFO_ATTRIBUTES, payload, credentials)

    async def _resolve_product_id_by_offer_id(self, *, offer_id: str, credentials: OzonCredentials) -> int:
        product = self.products.get_by_offer_id(client_id=credentials.client_id, offer_id=offer_id)
        if product and product.get("product_id") is not None:
            return int(product["product_id"])

        data = await self.forwarder.post(OzonEndpoint.PRODUCT_INFO_LIST, {"offer_id": [offer_id]}, credentials)
        items = _response_items(data)
        if not items:
            raise ServiceError(
                "Product not found by offer_id",
                status_code=404,
                detail={"offer_id": offer_id},
            )

        item = items[0]
        product_id = _item_product_id(item)
        if product_id is None:
            raise ServiceError(
                "Product has no product_id yet",
                status_code=409,
                detail={"offer_id": offer_id},
            )

        self.products.update_identifiers_from_info_item(client_id=credentials.client_id, item=item)
        return product_id


def _response_items(data: dict[str, Any]) -> list[dict[str, Any]]:
    if isinstance(data.get("items"), list):
        return data["items"]
    result = data.get("result")
    if isinstance(result, dict) and isinstance(result.get("items"), list):
        return result["items"]
    return []


def _item_product_id(item: dict[str, Any]) -> int | None:
    value = item.get("id") or item.get("product_id")
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
