from typing import Any

from app.clients.ozon_endpoints import OzonEndpoint
from app.core.security import OzonCredentials
from app.repositories.products import ProductRepository
from app.repositories.tasks import ImportTaskItemRepository, ImportTaskRepository
from app.services.credential_store import CredentialStore
from app.services.ozon_forwarder import OzonForwarder


def task_id_from_import_response(data: dict[str, Any]) -> int | None:
    result = data.get("result")
    if isinstance(result, dict) and result.get("task_id") is not None:
        return int(result["task_id"])
    if data.get("task_id") is not None:
        return int(data["task_id"])
    return None


def status_from_import_info(data: dict[str, Any]) -> str:
    result = data.get("result") or {}
    items = result.get("items") or []
    if not items:
        return "pending"
    statuses = {item.get("status", "pending") for item in items}
    if statuses == {"imported"}:
        return "imported"
    if statuses == {"skipped"}:
        return "skipped"
    if "failed" in statuses and len(statuses) == 1:
        return "failed"
    if "pending" in statuses:
        return "pending"
    if "failed" in statuses:
        return "partial"
    return next(iter(statuses))


class ProductImportService:
    def __init__(
        self,
        forwarder: OzonForwarder | None = None,
        products: ProductRepository | None = None,
        tasks: ImportTaskRepository | None = None,
        task_items: ImportTaskItemRepository | None = None,
        credentials: CredentialStore | None = None,
    ) -> None:
        self.forwarder = forwarder or OzonForwarder()
        self.products = products or ProductRepository()
        self.tasks = tasks or ImportTaskRepository()
        self.task_items = task_items or ImportTaskItemRepository()
        self.credentials = credentials or CredentialStore()

    async def import_products(self, *, payload: dict[str, Any], credentials: OzonCredentials) -> dict[str, Any]:
        limit_data = await self.forwarder.post(OzonEndpoint.PRODUCT_INFO_LIMIT, {}, credentials)
        import_data = await self.forwarder.post(OzonEndpoint.PRODUCT_IMPORT, payload, credentials)
        task_id = task_id_from_import_response(import_data)

        credential_ref = self.credentials.store(credentials) if task_id else None
        if task_id:
            self.tasks.insert(
                client_id=credentials.client_id,
                task_id=task_id,
                action_type="product_import",
                status="pending",
                credential_ref=credential_ref,
                request_payload=payload,
                response_payload=import_data,
            )

        for item in payload.get("items") or []:
            self.products.upsert_from_import_item(
                client_id=credentials.client_id,
                item=item,
                task_id=task_id,
                status="pending",
            )

        return {
            "limit": limit_data,
            "import_result": import_data,
            "task_id": task_id,
            "credential_ref_saved": bool(credential_ref),
        }

    async def poll_import_task(self, *, task_id: int, credentials: OzonCredentials) -> dict[str, Any]:
        task = self.tasks.get(client_id=credentials.client_id, task_id=task_id)
        polling_credentials = credentials
        if task and task.get("credential_ref"):
            polling_credentials = self.credentials.load(task["credential_ref"]) or credentials

        data = await self.forwarder.post(OzonEndpoint.PRODUCT_IMPORT_INFO, {"task_id": task_id}, polling_credentials)
        status = status_from_import_info(data)
        result = data.get("result") or {}
        errors = []
        for item in result.get("items") or []:
            self.task_items.upsert(client_id=credentials.client_id, task_id=task_id, item=item)
            self.products.update_from_task_item(client_id=credentials.client_id, item=item)
            if item.get("errors"):
                errors.append({"offer_id": item.get("offer_id"), "errors": item.get("errors")})

        self.tasks.update_result(
            client_id=credentials.client_id,
            task_id=task_id,
            status=status,
            result_payload=data,
            error_payload=errors or None,
        )
        return {"task_id": task_id, "status": status, "data": data}

    async def update_attributes(self, *, payload: dict[str, Any], credentials: OzonCredentials) -> dict[str, Any]:
        data = await self.forwarder.post(OzonEndpoint.PRODUCT_ATTRIBUTES_UPDATE, payload, credentials)
        task_id = task_id_from_import_response(data)
        if task_id:
            self.tasks.insert(
                client_id=credentials.client_id,
                task_id=task_id,
                action_type="attribute_update",
                status="pending",
                credential_ref=self.credentials.store(credentials),
                request_payload=payload,
                response_payload=data,
            )
        return {"task_id": task_id, "data": data}
