"""Core application infrastructure."""
